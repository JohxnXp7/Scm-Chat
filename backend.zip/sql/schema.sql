create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  email text unique,
  name text not null default '',
  bio text not null default '',
  avatar_url text,
  friends_count integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles add column if not exists email text unique;

create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','rejected','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (sender_id <> receiver_id)
);

create unique index if not exists friend_requests_pending_unique
on public.friend_requests (sender_id, receiver_id)
where status = 'pending';

create table if not exists public.friendships (
  user_id uuid not null references public.profiles(id) on delete cascade,
  friend_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, friend_id),
  check (user_id <> friend_id)
);

create index if not exists friendships_friend_idx on public.friendships (friend_id);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  type text not null default 'private' check (type in ('private','group')),
  name text,
  description text,
  avatar_url text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('member','admin')),
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  content text not null,
  reply_to_message_id uuid references public.messages(id) on delete set null,
  edited_at timestamptz,
  deleted_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.message_reactions (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  reaction text not null,
  created_at timestamptz not null default now(),
  primary key (message_id, user_id, reaction)
);

create index if not exists messages_conversation_created_idx
on public.messages (conversation_id, created_at);

create index if not exists conversation_members_user_idx
on public.conversation_members (user_id);

-- Profil automatique après inscription Supabase Auth.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, username, email, name)
  values (
    new.id,
    coalesce(nullif(lower(new.raw_user_meta_data->>'username'), ''), 'user_' || substr(new.id::text, 1, 8)),
    new.email,
    coalesce(new.raw_user_meta_data->>'name', new.raw_user_meta_data->>'username', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- RLS.
alter table public.profiles enable row level security;
alter table public.friend_requests enable row level security;
alter table public.friendships enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.message_reactions enable row level security;

-- Profiles: lecture publique minimale pour permettre la recherche d'utilisateurs.
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated using (true);

drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Friend requests.
drop policy if exists friend_requests_select on public.friend_requests;
create policy friend_requests_select on public.friend_requests for select to authenticated
using (sender_id = auth.uid() or receiver_id = auth.uid());

drop policy if exists friend_requests_insert on public.friend_requests;
create policy friend_requests_insert on public.friend_requests for insert to authenticated
with check (sender_id = auth.uid());

drop policy if exists friend_requests_update on public.friend_requests;
-- A receiver may reject a pending request; a sender may cancel their own.
-- Acceptance is handled only by accept_friend_request(), which validates the receiver.
create policy friend_requests_update on public.friend_requests for update to authenticated
using (
  status = 'pending'
  and (receiver_id = auth.uid() or sender_id = auth.uid())
)
with check (
  (receiver_id = auth.uid() and status = 'rejected')
  or (sender_id = auth.uid() and status = 'cancelled')
);


-- Friendships.
drop policy if exists friendships_select on public.friendships;
create policy friendships_select on public.friendships for select to authenticated
using (user_id = auth.uid() or friend_id = auth.uid());

-- Conversations / members.
drop policy if exists conversations_select on public.conversations;
create policy conversations_select on public.conversations for select to authenticated
using (exists (select 1 from public.conversation_members cm where cm.conversation_id = id and cm.user_id = auth.uid()));

drop policy if exists conversations_insert on public.conversations;
create policy conversations_insert on public.conversations for insert to authenticated
with check (created_by = auth.uid());

drop policy if exists members_select on public.conversation_members;
create policy members_select on public.conversation_members for select to authenticated
using (exists (select 1 from public.conversation_members mine where mine.conversation_id = conversation_id and mine.user_id = auth.uid()));

drop policy if exists members_insert on public.conversation_members;
create policy members_insert on public.conversation_members for insert to authenticated
with check (user_id = auth.uid() or exists (select 1 from public.conversation_members admin where admin.conversation_id = conversation_id and admin.user_id = auth.uid() and admin.role = 'admin'));

-- Messages.
drop policy if exists messages_select on public.messages;
create policy messages_select on public.messages for select to authenticated
using (exists (select 1 from public.conversation_members cm where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()));

drop policy if exists messages_insert on public.messages;
create policy messages_insert on public.messages for insert to authenticated
with check (sender_id = auth.uid() and exists (select 1 from public.conversation_members cm where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()));

drop policy if exists messages_update on public.messages;
create policy messages_update on public.messages for update to authenticated
using (sender_id = auth.uid())
with check (sender_id = auth.uid());

-- Reactions.
drop policy if exists reactions_select on public.message_reactions;
create policy reactions_select on public.message_reactions for select to authenticated
using (
  exists (
    select 1 from public.messages m
    join public.conversation_members cm on cm.conversation_id = m.conversation_id
    where m.id = message_id and cm.user_id = auth.uid()
  )
);

drop policy if exists reactions_insert on public.message_reactions;
create policy reactions_insert on public.message_reactions for insert to authenticated
with check (
  user_id = auth.uid()
  and exists (
    select 1 from public.messages m
    where m.id = message_id
      and public.is_conversation_member(m.conversation_id, auth.uid())
  )
);

drop policy if exists reactions_delete on public.message_reactions;
create policy reactions_delete on public.message_reactions for delete to authenticated using (user_id = auth.uid());


-- Storage: avatars. The bucket is public so avatar URLs can be displayed in profiles.
insert into storage.buckets (id, name, public) values ('avatars', 'avatars', true)
on conflict (id) do update set public = true;

drop policy if exists avatars_read on storage.objects;
create policy avatars_read on storage.objects for select to public using (bucket_id = 'avatars');

drop policy if exists avatars_insert_own on storage.objects;
create policy avatars_insert_own on storage.objects for insert to authenticated
with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists avatars_update_own on storage.objects;
create policy avatars_update_own on storage.objects for update to authenticated
using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists avatars_delete_own on storage.objects;
create policy avatars_delete_own on storage.objects for delete to authenticated
using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create or replace function public.increment_friends_count(uid uuid)
returns void language sql security definer set search_path = public as $$
  update public.profiles set friends_count = friends_count + 1, updated_at = now() where id = uid;
$$;
revoke all on function public.increment_friends_count(uuid) from public, anon, authenticated;


-- SCM CHAT core functions and safer policies (re-runnable).
create or replace function public.is_conversation_member(p_conversation_id uuid, p_user_id uuid default auth.uid())
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.conversation_members cm where cm.conversation_id=p_conversation_id and cm.user_id=p_user_id);
$$;
revoke all on function public.is_conversation_member(uuid,uuid) from public;
grant execute on function public.is_conversation_member(uuid,uuid) to authenticated;

-- Avoid recursive RLS checks on conversation_members.
drop policy if exists members_select on public.conversation_members;
create policy members_select on public.conversation_members for select to authenticated
using (public.is_conversation_member(conversation_id, auth.uid()));
create or replace function public.is_conversation_admin(p_conversation_id uuid, p_user_id uuid default auth.uid())
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.conversation_members cm where cm.conversation_id=p_conversation_id and cm.user_id=p_user_id and cm.role='admin');
$$;
revoke all on function public.is_conversation_admin(uuid,uuid) from public;
grant execute on function public.is_conversation_admin(uuid,uuid) to authenticated;
drop policy if exists members_insert on public.conversation_members;
-- Users cannot add themselves to arbitrary conversations. Trusted SECURITY DEFINER
-- RPCs create conversations and memberships; admins may add members to existing groups.
create policy members_insert on public.conversation_members for insert to authenticated
with check (public.is_conversation_admin(conversation_id,auth.uid()));

-- Friendships may only be created by the accepting request's participants through the function below.
drop policy if exists friendships_insert_own on public.friendships;
create policy friendships_insert_own on public.friendships for insert to authenticated with check (user_id=auth.uid() and exists(select 1 from public.friend_requests fr where fr.status='accepted' and ((fr.sender_id=auth.uid() and fr.receiver_id=friend_id) or (fr.receiver_id=auth.uid() and fr.sender_id=friend_id))));
drop policy if exists friendships_delete_own on public.friendships;
create policy friendships_delete_own on public.friendships for delete to authenticated using (user_id=auth.uid());

create or replace function public.accept_friend_request(p_request_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare r public.friend_requests%rowtype; uid uuid := auth.uid();
begin
  select * into r from public.friend_requests where id=p_request_id and receiver_id=uid and status='pending' for update;
  if not found then raise exception 'Demande introuvable ou déjà traitée.'; end if;
  update public.friend_requests set status='accepted', updated_at=now() where id=r.id;
  insert into public.friendships(user_id,friend_id) values (r.sender_id,r.receiver_id),(r.receiver_id,r.sender_id) on conflict do nothing;
end; $$;
revoke all on function public.accept_friend_request(uuid) from public;
grant execute on function public.accept_friend_request(uuid) to authenticated;

create or replace function public.create_private_conversation(p_friend_id uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare uid uuid := auth.uid(); cid uuid;
begin
  if uid is null or p_friend_id is null or p_friend_id=uid then raise exception 'Destinataire invalide.'; end if;
  if not exists(select 1 from public.friendships where user_id=uid and friend_id=p_friend_id) then raise exception 'Vous devez être amis.'; end if;
  select mine.conversation_id into cid
  from public.conversation_members mine
  join public.conversations c on c.id=mine.conversation_id and c.type='private'
  join public.conversation_members other on other.conversation_id=mine.conversation_id and other.user_id=p_friend_id
  where mine.user_id=uid limit 1;
  if cid is not null then return cid; end if;
  insert into public.conversations(type,created_by) values('private',uid) returning id into cid;
  insert into public.conversation_members(conversation_id,user_id,role) values(cid,uid,'member'),(cid,p_friend_id,'member');
  return cid;
end; $$;
revoke all on function public.create_private_conversation(uuid) from public;
grant execute on function public.create_private_conversation(uuid) to authenticated;

create or replace function public.create_group(p_name text, p_description text default '')
returns uuid language plpgsql security definer set search_path=public as $$
declare uid uuid := auth.uid(); cid uuid; clean_name text := trim(coalesce(p_name,''));
begin
  if uid is null then raise exception 'Connexion requise.'; end if;
  if clean_name='' or length(clean_name)>60 then raise exception 'Le nom du groupe doit contenir de 1 à 60 caractères.'; end if;
  insert into public.conversations(type,name,description,created_by) values('group',clean_name,left(trim(coalesce(p_description,'')),180),uid) returning id into cid;
  insert into public.conversation_members(conversation_id,user_id,role) values(cid,uid,'admin');
  return cid;
end; $$;
revoke all on function public.create_group(text,text) from public;
grant execute on function public.create_group(text,text) to authenticated;

-- Private file storage for chat attachments. Files are shared only with conversation members via app links.
insert into storage.buckets(id,name,public,file_size_limit) values('chat-files','chat-files',false,15728640)
on conflict(id) do update set public=false,file_size_limit=15728640;
drop policy if exists chat_files_read_member on storage.objects;
create policy chat_files_read_member on storage.objects for select to authenticated using(bucket_id='chat-files' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_conversation_member(((storage.foldername(name))[2])::uuid,auth.uid())));
drop policy if exists chat_files_insert_own on storage.objects;
create policy chat_files_insert_own on storage.objects for insert to authenticated with check(bucket_id='chat-files' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists chat_files_delete_own on storage.objects;
create policy chat_files_delete_own on storage.objects for delete to authenticated using(bucket_id='chat-files' and (storage.foldername(name))[1]=auth.uid()::text);

create or replace function public.add_group_member(p_conversation_id uuid, p_user_id uuid)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.is_conversation_admin(p_conversation_id,auth.uid()) then raise exception 'Administrateur requis.'; end if;
  if not exists(select 1 from public.conversations where id=p_conversation_id and type='group') then raise exception 'Groupe introuvable.'; end if;
  if not exists(select 1 from public.friendships where user_id=auth.uid() and friend_id=p_user_id) then raise exception 'Tu peux ajouter uniquement un ami.'; end if;
  insert into public.conversation_members(conversation_id,user_id,role) values(p_conversation_id,p_user_id,'member') on conflict do nothing;
end; $$;
revoke all on function public.add_group_member(uuid,uuid) from public;
grant execute on function public.add_group_member(uuid,uuid) to authenticated;

create or replace function public.set_group_member_role(p_conversation_id uuid,p_user_id uuid,p_role text)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.is_conversation_admin(p_conversation_id,auth.uid()) then raise exception 'Administrateur requis.'; end if;
  if p_role not in ('admin','member') then raise exception 'Rôle invalide.'; end if;
  if not exists(select 1 from public.conversations where id=p_conversation_id and type='group') then raise exception 'Groupe introuvable.'; end if;
  update public.conversation_members set role=p_role where conversation_id=p_conversation_id and user_id=p_user_id;
  if not found then raise exception 'Membre introuvable.'; end if;
end; $$;
revoke all on function public.set_group_member_role(uuid,uuid,text) from public;
grant execute on function public.set_group_member_role(uuid,uuid,text) to authenticated;

create or replace function public.remove_group_member(p_conversation_id uuid,p_user_id uuid)
returns void language plpgsql security definer set search_path=public as $$
begin
  if p_user_id<>auth.uid() and not public.is_conversation_admin(p_conversation_id,auth.uid()) then raise exception 'Administrateur requis pour retirer un autre membre.'; end if;
  if not exists(select 1 from public.conversations where id=p_conversation_id and type='group') then raise exception 'Groupe introuvable.'; end if;
  delete from public.conversation_members where conversation_id=p_conversation_id and user_id=p_user_id;
  if not found then raise exception 'Membre introuvable.'; end if;
end; $$;
revoke all on function public.remove_group_member(uuid,uuid) from public;
grant execute on function public.remove_group_member(uuid,uuid) to authenticated;

-- Do not expose email addresses through profile search. Frontend queries only these public columns.
revoke all on table public.profiles from anon, authenticated;
grant select (id,username,name,bio,avatar_url,friends_count,created_at,updated_at) on table public.profiles to authenticated;
grant update (username,name,bio,avatar_url,updated_at) on table public.profiles to authenticated;
