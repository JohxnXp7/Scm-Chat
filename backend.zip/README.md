# SCM CHAT Backend

Backend Node.js + Express + Supabase + Socket.IO.

## Installation

```bash
cd backend
npm install
```

Copie `.env.example` vers `.env`, puis ajoute les clés Supabase côté serveur.

```bash
npm run dev
```

API: `http://localhost:3000/api`

Le `SUPABASE_SERVICE_ROLE_KEY` ne doit jamais être envoyé au frontend.

## Ordre de configuration

1. Exécuter `sql/schema.sql` dans Supabase SQL Editor.
2. Activer Email/Password dans Supabase Auth.
3. Configurer Google OAuth si Google est utilisé.
4. Renseigner `js/config.js` côté frontend avec l'URL et la clé ANON.
5. Renseigner `.env` côté backend.
6. Lancer le backend puis servir le dossier frontend.
