import { Router } from 'express';
import { supabase, supabaseAdmin } from '../supabase.js';
const router = Router();
const db = () => supabaseAdmin || supabase;
router.get('/email-by-username', async (req,res)=>{ const username=String(req.query.username||'').trim().toLowerCase(); if(!username)return res.status(400).json({error:'Username requis.'}); const {data,error}=await db().from('profiles').select('email').eq('username',username).maybeSingle(); if(error||!data?.email)return res.status(404).json({error:'Username introuvable.'}); res.json({email:data.email}); });
export default router;
