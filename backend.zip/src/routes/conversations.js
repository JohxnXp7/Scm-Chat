import { Router } from 'express';
import { requireAuth } from '../middleware.js';
import { createUserClient } from '../supabase.js';
const router=Router();
router.get('/',requireAuth,async(req,res)=>{const db=createUserClient(req.accessToken);const {data,error}=await db.from('conversation_members').select('conversation_id,role,conversations(*)').eq('user_id',req.user.id);if(error)return res.status(500).json({error:error.message});res.json({conversations:data});});
router.post('/private',requireAuth,async(req,res)=>{const db=createUserClient(req.accessToken);const friendId=req.body?.friendId;if(!friendId||friendId===req.user.id)return res.status(400).json({error:'Ami invalide.'});const {data,error}=await db.rpc('create_private_conversation',{p_friend_id:friendId});if(error)return res.status(400).json({error:error.message});res.status(201).json({conversationId:data});});
export default router;
