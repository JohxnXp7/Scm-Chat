import express from 'express';
import cors from 'cors';
import http from 'node:http';
import { Server } from 'socket.io';
import { config } from './config.js';
import router from './routes/index.js';

const app = express();
const server = http.createServer(app);

app.use(cors({ origin: config.frontendUrl, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use('/api', router);

const io = new Server(server, {
  cors: { origin: config.frontendUrl, methods: ['GET', 'POST'] }
});

// Socket.IO is intentionally not allowed to join arbitrary conversation rooms.
// The frontend currently uses Supabase Realtime directly. If Socket.IO is enabled
// later, authenticate the socket token and verify conversation membership before joining.

server.listen(config.port, () => {
  console.log(`SCM CHAT backend running on http://localhost:${config.port}`);
});
