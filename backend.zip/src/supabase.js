import { createClient } from '@supabase/supabase-js';
import { config } from './config.js';

export const supabase = createClient(
  config.supabaseUrl || 'https://placeholder.supabase.co',
  config.supabaseAnonKey || 'placeholder'
);

export function createUserClient(accessToken) {
  return createClient(
    config.supabaseUrl || 'https://placeholder.supabase.co',
    config.supabaseAnonKey || 'placeholder',
    {
      auth: { autoRefreshToken: false, persistSession: false },
      global: { headers: { Authorization: `Bearer ${accessToken}` } }
    }
  );
}

export const supabaseAdmin = config.serviceRoleKey
  ? createClient(config.supabaseUrl, config.serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false }
    })
  : null;
